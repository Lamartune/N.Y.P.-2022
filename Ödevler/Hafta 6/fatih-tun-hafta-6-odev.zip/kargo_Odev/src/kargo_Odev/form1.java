package kargo_Odev;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;


public class form1 extends JFrame {

	private JPanel contentPane;
	int s = 0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					form1 frame = new form1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public form1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("S\u0130PAR\u0130\u015E S\u00DCREC\u0130");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 414, 14);
		contentPane.add(lblNewLabel);
		
		JButton b1 = new JButton("HAZIRLANIYOR");
		b1.setEnabled(false);
		b1.setBackground(Color.YELLOW);
		b1.setBounds(20, 36, 126, 23);
		contentPane.add(b1);
		
		JButton b2 = new JButton("KARGOYA VER\u0130LECEK");
		b2.setEnabled(false);
		b2.setBackground(Color.YELLOW);
		b2.setBounds(20, 68, 126, 23);
		contentPane.add(b2);
		
		JButton b3 = new JButton("KARGODA");
		b3.setEnabled(false);
		b3.setBackground(Color.YELLOW);
		b3.setBounds(20, 100, 126, 23);
		contentPane.add(b3);
		
		JButton b4 = new JButton("TESL\u0130M ED\u0130LD\u0130");
		b4.setEnabled(false);
		b4.setBackground(Color.YELLOW);
		b4.setBounds(20, 134, 126, 23);
		contentPane.add(b4);
		
		JButton b5 = new JButton("\u0130ADE S\u00DCREC\u0130NDE");
		b5.setEnabled(false);
		b5.setBackground(Color.YELLOW);
		b5.setBounds(20, 166, 126, 23);
		contentPane.add(b5);
		
		JButton b6 = new JButton("\u0130ADE ED\u0130LD\u0130");
		b6.setEnabled(false);
		b6.setBackground(Color.YELLOW);
		b6.setBounds(21, 199, 126, 23);
		contentPane.add(b6);
		
		JLabel lblFatihTn = new JLabel("Fatih T\u00DCN - 20410051048");
		lblFatihTn.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFatihTn.setBounds(293, 236, 131, 14);
		contentPane.add(lblFatihTn);
		
		JButton bfw = new JButton("\u0130LER\u0130");
		
		bfw.setBounds(306, 151, 89, 23);
		contentPane.add(bfw);
		
		JLabel lbldurum = new JLabel("S\u0130PAR\u0130\u015E S\u00DCREC\u0130");
		lbldurum.setForeground(Color.BLACK);
		lbldurum.setHorizontalAlignment(SwingConstants.CENTER);
		lbldurum.setBounds(171, 114, 258, 14);
		contentPane.add(lbldurum);
		
		JLabel lblDurum = new JLabel("DURUM:");
		lblDurum.setFont(new Font("Tahoma", Font.PLAIN, 27));
		lblDurum.setHorizontalAlignment(SwingConstants.CENTER);
		lblDurum.setBounds(193, 51, 213, 43);
		contentPane.add(lblDurum);
		
		JButton bres = new JButton("GER\u0130");
		bres.setBounds(207, 151, 89, 23);
		contentPane.add(bres);
		
		
		
		bfw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (s==0) {
					b1.setBackground(Color.GREEN);
					lbldurum.setText(Siparis.values()[s].toString());
					s++;
				}else if(s==1) {
					b2.setBackground(Color.GREEN);
					lbldurum.setText(Siparis.values()[s].toString());
					s++;
				}
				else if(s==2) {
					b3.setBackground(Color.GREEN);
					lbldurum.setText(Siparis.values()[s].toString());
					s++;
				}
				else if(s==3) {
					b4.setBackground(Color.GREEN);
					lbldurum.setText(Siparis.values()[s].toString());
					s++;
				}
				else if(s==4) {
					b5.setBackground(Color.GREEN);
					lbldurum.setText(Siparis.values()[s].toString());
					s++;
				}
				else if(s==5) {
					b6.setBackground(Color.GREEN);
					lbldurum.setText(Siparis.values()[s].toString());
					s++;
				}
				
			}
		});
		
		bres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (s==1) {
					s--;
					b1.setBackground(Color.YELLOW);
					lbldurum.setText(Siparis.values()[s-1].toString());
				}else if(s==2) {
					s--;
					b2.setBackground(Color.YELLOW);
					lbldurum.setText(Siparis.values()[s-1].toString());
				}else if(s==3) {
					s--;
					b3.setBackground(Color.YELLOW);
					lbldurum.setText(Siparis.values()[s-1].toString());
				}else if(s==4) {
					s--;
					b4.setBackground(Color.YELLOW);
					lbldurum.setText(Siparis.values()[s-1].toString());
				}else if(s==5) {
					s--;
					b5.setBackground(Color.YELLOW);
					lbldurum.setText(Siparis.values()[s-1].toString());
				}else if(s==6) {
					s--;
					b6.setBackground(Color.YELLOW);
					lbldurum.setText(Siparis.values()[s-1].toString());
				}
				
			}
		});
	}
}
