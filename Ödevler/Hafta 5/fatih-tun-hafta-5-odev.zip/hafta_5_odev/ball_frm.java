package hafta_5_odev;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.Rectangle;

public class ball_frm extends JFrame {
    private JButton btn1;
    private JPanel panel1;
    private JButton btn3;
    private JButton btn2;
    static int x,y,z,spx,spy,spz,x2,y2,z2,spx2,spy2,spz2;
    Timer t;
    TimerTask g;

    public ball_frm() {

        add(panel1);
        setSize(800,800);
        setTitle("FATIH TUN-20410051048");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        Image img1 = null;
        try {
            img1 = ImageIO.read(getClass().getResource("images/b.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Image img2 = null;
        try {
            img2 = ImageIO.read(getClass().getResource("images/f.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Image img3 = null;
        try {
            img3 = ImageIO.read(getClass().getResource("images/p.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        btn1.setBorder(null);
        btn1.setOpaque(false);
        btn1.setBorderPainted(false);
        btn1.setContentAreaFilled(false);
        btn1.setIcon(new ImageIcon(img1));

        btn2.setBorder(null);
        btn2.setOpaque(false);
        btn2.setBorderPainted(false);
        btn2.setContentAreaFilled(false);
        btn2.setIcon(new ImageIcon(img2));

        btn3.setBorder(null);
        btn3.setOpaque(false);
        btn3.setBorderPainted(false);
        btn3.setContentAreaFilled(false);
        btn3.setIcon(new ImageIcon(img2));
        btn3.setIcon(new ImageIcon(img3));

        x = 400;
        y= 400;
        z = 400;

        x2= 200;
        y2= 200;
        z2= 200;

        spx=3;
        spy=8;
        spz=5;

        spx2=2;
        spy2=4;
        spz2=6;

        t = new Timer();
        g = new TimerTask() {
            @Override
            public void run() {
                x += spx;
                y += spy;
                z += spz;
                x2 += spx2;
                y2 += spy2;
                z2 += spz2;
                //Hocam if bloklarıyla çakıştırmayı denedim ama işler biraz karıştı halledemedim :d.
                if(x>=740 || x<=0 && x>=y || x<=y && x>=z || x<=z) spx*=-1;
                if(y>=720 || y<=0 && y>=x || y<=x && y>=z || y<=z) spy*=-1;
                if(z>=720 || z<=0 && z>=x || z<=x && z>=y || z<=y) spz*=-1;
                if(x2>=740 || x2<=0) spx2*=-1;
                if(y2>=720 || y2<=0) spy2*=-1;
                if(z2>=720 || z2<=0) spz2*=-1;
                btn1.setBounds(x,y,50,50);
                btn2.setBounds(y,z,50,50);
                btn3.setBounds(x,z,50,50);
            }
        };

        t.schedule(g,0,10);

        //Çarpışma olayını araştırdım fakat bulduğum sonuçları koduma entegre edemedim hocam. Bulduğum sonuçlardan bazıları aşağıda...

        /*// Two rectangles, assume the class name is `Rect`
        Rect r1 = new Rect(x1, y2, w1, h1);
        Rect r2 = new Rect(x3, y4, w2, h2);

// get the coordinates of other points needed later:
        int x2 = x1 + w1;
        int x4 = x3 + w2;
        int y1 = y2 - h1;
        int y3 = y4 - h2;

// find intersection:
        int xL = Math.max(x1, x3);
        int xR = Math.min(x2, x4);
        if (xR <= xL)
            return null;
        else {
            int yT = Math.max(y1, y3);
            int yB = Math.min(y2, y4);
            if (yB <= yT)
                return null;
            else
                return new Rect(xL, yB, xR-xL, yB-yT);
        }
        */

        /*Rectangle bounds = new Rectangle(0, 0, -1, -1);
        for (int i = 0; i < points.length; i++) {
            bounds.add(points[i]);
        }*/
}

    }