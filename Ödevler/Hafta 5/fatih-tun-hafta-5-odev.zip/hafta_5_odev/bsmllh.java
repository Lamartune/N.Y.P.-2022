package hafta_5_odev;

import javax.swing.*;

public class bsmllh {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() { //ekrana basılması için thread
            @Override
            public void run() {
                ball_frm f1 = new ball_frm();
                f1.setVisible(true);
            }
        });
    }
}
