package hafta_4_odev;

import java.util.Scanner;

public class throw_exception_3_5 {
    static int tek(int a) {
        int tek = 0;
        if(a%3==0 && a%5==0) {
            System.out.println(a + " sayısı 3 ve 5'e tam olarak bölünmektedir.");
        } else {
            throw new ArithmeticException("Girmiş olduğunuz sayı 3 ve 5 e tam olarak bölünmemektedir!");
        }
        return tek;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Bir sayı giriniz");
        tek(s.nextInt());
    }
}
