package hafta_4_odev;

import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class ad_soyad_timer {
    static Timer t1;
    static TimerTask g1,g2;
    static String ad,soyad;

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        System.out.println("Adınızı Giriniz:");
        ad = s.nextLine();
        System.out.println("Soyadınızı Giriniz:");
        soyad = s.nextLine();
        System.out.println("Her 3 saniyede bir adınız, her 5 saniyede bir soyadınız yazdırılacaktır...");

            t1 = new Timer();

            g1 = new TimerTask() {
                @Override
                public void run() {
                    System.out.println(ad);
                }
            };

            g2 = new TimerTask() {
                @Override
                public void run() {
                    System.out.println(soyad);
                }
            };

            t1.schedule(g1,3000,3000);
            t1.schedule(g2,5000,5000);

    }
}
