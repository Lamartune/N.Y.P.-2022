package hafta_3_odev;

public class polymorphism_odev {
    static class car{
        void fuel() {
            System.out.println("Tüplü ve Öfkeli");
        }
    }
    class suv extends car{ //miras alma islemi
        void fuel(){
            System.out.println("En çok tercih edilen aile arabası SUV");
        }
    }
    class engine extends suv{
        void fuel(){
            System.out.println("V8 Motor bir harika!");
        }

        public void main(String[] args) {
            car a1, a2, a3; //her biri için nesne ürettim.
            a1 = new car();
            a2 = new suv();
            a3 = new engine();
            a1.fuel();
            a2.fuel();
            a3.fuel();
        }
    }
}
