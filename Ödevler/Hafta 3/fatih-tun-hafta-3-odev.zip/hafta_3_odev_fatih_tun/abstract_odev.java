package hafta_3_odev;

public abstract class abstract_odev { //abstract sınıf burada tanımlanır.
    abstract void soyutM(); //en az 1 tane abstract method oması lazım.

    void yaz() { //somut sınıflar da içerebilir
        System.out.println("Abstract sınıf");
    }

    public abstract_odev(){
        //TODO Auto-generated constructor stub
    }
}

class concreteClass extends abstract_odev{

    @Override
    void soyutM() { //Soyut methodu Override ettim.
        System.out.println("Concrete sınıf");
    }
}

class absExample{
    public static void main(String[] args) {
        concreteClass conC = new concreteClass(); //abstract sınıfın nesnesi üretilemez bu yüzden concrete sınıf ile nesne ürettim.
        conC.soyutM();
        conC.yaz();
    }
}