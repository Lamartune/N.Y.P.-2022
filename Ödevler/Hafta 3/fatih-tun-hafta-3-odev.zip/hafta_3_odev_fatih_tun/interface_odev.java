package hafta_3_odev;

public class interface_odev {
    interface client{
        public void clientId();
        public void clientGender();
    }

    static class clientType implements client{
        public void clientId(){
            //yapılacaklar
        }

        @Override //methodu implement ettim.
        public void clientGender() {

        }
    }
}

class interfaceClient{
    public static void main(String[] args) { //interface i aynı normal sınıf gibi tanımladım.
        interface_odev.clientType cT = new interface_odev.clientType();
        cT.clientId();
    }
}