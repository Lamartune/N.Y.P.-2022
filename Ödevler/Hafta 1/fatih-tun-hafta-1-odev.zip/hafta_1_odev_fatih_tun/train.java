package hafta_1_odev_fatih_tun;

public class train extends vehicle{
    private Integer num_carriage;
    public void run() {
        //yapılacak isler
    }
}
