package hafta_1_odev_fatih_tun;

public class motorcycle extends roadvehicle{
    private double saddle_height;
    public void run() {
        //yapılacak isler
    }
}
