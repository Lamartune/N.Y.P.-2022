package hafta_1_odev_fatih_tun;

public class roadvehicle extends vehicle {
    private int num_wheels;
    public void run() {
        //yapılacak isler
    }
}
