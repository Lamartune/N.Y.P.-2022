package hafta_1_odev_fatih_tun;

public class ship extends vehicle{
    private double draft_width;
    public void run() {
        //yapılacak isler
    }
}
