package hafta_1_odev_fatih_tun;

public class truck extends roadvehicle{
    private int num_doors;
    public void run() {
        //yapılacak isler
    }
}
