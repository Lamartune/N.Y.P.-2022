package hafta_1_odev_fatih_tun;

public class vehicle {
    private String maker;
    public void run() {
        //yapılacak isler
    }
}