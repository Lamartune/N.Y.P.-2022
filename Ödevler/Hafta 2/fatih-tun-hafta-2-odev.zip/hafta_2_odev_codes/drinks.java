package hafta_2_odev;

public class drinks {
   int coffee=15;
   int sparkling_water=5;
   static float ortalama;

   public static float ortalama(int coffe,int sparkling_water){
      return (float) (coffe+sparkling_water)/2;
   }

   public static float ortalama(int coffee, int sparkling_water, int c){ //üstteki ortalama methodu overload edildi
      return (float) (coffee+sparkling_water+c)/3;
   }

   public int fark(int coffee,int sparkling_water){
      return coffee - sparkling_water;
   }

   //Constructer - Yapıcı method
   drinks(){
      this.ortalama = (float) (this.coffee + this.sparkling_water)/2;
   }

   //constructer methodu overload ediyorum.
   drinks(int coffee,int sparkling_water){
      this.coffee = coffee; //burada sınıf değişkeni olan coffee ve sparkling_water değişkenlerini
      this.sparkling_water = sparkling_water; //constructer method ile gönderdiğim iki değişkenle yeniden belirliyorum.
      this.ortalama = (float)(this.coffee+this.sparkling_water)/2;
   }

   public static void main(String[] args) {

      drinks d = new drinks(); //constructer method
      System.out.println(ortalama);

   }
}