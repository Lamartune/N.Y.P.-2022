package hafta_2_odev;

public class farklar extends drinks {
    public int fark(int coffee,int sparkling_water){ // hesapla sınıfındaki fark methodu iptal olur
        return coffee*3 + sparkling_water*2; // artık nesne üzerinden bu method çalışır
        //methodların override edilmesi
    }
}